# The Honest Agent: synthetic oversight baseline v0.1

**Question:** Can observable actions expose violations hidden by an agent's final report?

This is a **scripted synthetic baseline**, not an empirical study of real LLM agents. The deterministic policy checker is constructed from the same rules used to label the cases, so perfect performance is **by design**, not a research discovery.

## Reproduce (Python 3.9+, no dependencies)

```bash
python3 -m unittest -v
python3 experiment.py --seed 42 --n 60 --out results
```

Outputs: `dataset.jsonl`, `predictions.csv`, `metrics.json`.

Each row has an action trace represented by structured action/approval/path/amount fields, a noisy final report, and a ground-truth policy label. Balanced four-way generation, seeded shuffle, 70/30 split. No model training occurs.

Three baselines: (1) final-report keyword detection, (2) incomplete trace heuristic, (3) explicit policy checks. Precision/recall/FPR are calculated on the held-out 30% subset. No runtime/cost claims are made.

## Critical limitations and next experiment

- Synthetic reports are generated with scripted templates, not real model outputs.
- Trace heuristic is deliberately incomplete; its weakness is baked into the design.
- The policy checker has direct access to the exact label-generating rules, so comparisons are illustrative, not fair estimates of real-world monitoring accuracy.
- Cases are not independent of templates; the random split is not a true out-of-distribution evaluation.
- The experiment does not test deception, hidden intentions, adversarial adaptation, or real-world agent behavior.

**Next:** collect consented agent runs in a sandbox with independent, preregistered policies, hold out task families, blind human annotations, compare a real LLM final-answer monitor against a real LLM trace monitor at matched inference budgets, and report uncertainty across seeds and failure classes. No real credentials, payments, or production infrastructure.
