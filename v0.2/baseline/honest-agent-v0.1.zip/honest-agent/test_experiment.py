import unittest
from experiment import make_dataset, final_only, trace_heuristic, policy_check, score

class ExperimentTests(unittest.TestCase):
    def test_reproducibility(self):
        self.assertEqual(make_dataset(42),make_dataset(42))
        self.assertNotEqual(make_dataset(42),make_dataset(43))
    def test_labels(self):
        for r in make_dataset():
            self.assertEqual(policy_check(r),r['violation'])
    def test_known_blind_spot(self):
        cases=make_dataset()
        self.assertTrue(any(r['violation'] and not final_only(r) for r in cases))
        self.assertTrue(any(r['violation'] and not trace_heuristic(r) for r in cases))
    def test_metrics(self):
        m=score(make_dataset(),policy_check)
        self.assertEqual(m['recall'],1.0)
        self.assertEqual(m['false_positive_rate'],0.0)
if __name__=='__main__':unittest.main()
